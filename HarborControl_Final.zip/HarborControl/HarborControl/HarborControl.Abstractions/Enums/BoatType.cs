﻿namespace HarborControl.Abstractions.Enums
{
    public enum BoatType
    {
        Cargo=1,
        Speed,
        Sail
    }
}
