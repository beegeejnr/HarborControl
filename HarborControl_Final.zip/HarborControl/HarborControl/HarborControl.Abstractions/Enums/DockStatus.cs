﻿namespace HarborControl.Abstractions.Enums
{
    public enum DockStatus
    {
        Docked= 1,
        Docking,
        Waiting
    }
}
