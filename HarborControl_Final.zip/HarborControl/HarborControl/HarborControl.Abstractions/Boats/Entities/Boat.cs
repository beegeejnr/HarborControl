﻿using HarborControl.Abstractions.Enums;
using System;

namespace HarborControl.Abstractions.Boats.Entities
{
    public class Boat
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public BoatType Type { get; set; }
        public int Speed { get; set; }
        public DockStatus Status { get; set; }
        public DateTime ArrivalTime { get; set; }
        public DateTime DockingTime { get; set; }
        public DateTime DockedTime { get; set; }
    }
}
