﻿using System;

namespace HarborControl.Abstractions.Boats.Commands
{
    public class EndDocking
    {
        public Guid BoatId { get; set; }
    }
}
