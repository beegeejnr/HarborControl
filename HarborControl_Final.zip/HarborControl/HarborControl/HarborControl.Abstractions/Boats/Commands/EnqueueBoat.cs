﻿using HarborControl.Abstractions.Boats.Entities;

namespace HarborControl.Abstractions.Boats.Commands
{
    public class EnqueueBoat
    {
        public Boat Boat { get; set; }
    }
}
