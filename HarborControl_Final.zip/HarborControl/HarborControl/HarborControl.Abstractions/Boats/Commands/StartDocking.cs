﻿using System;

namespace HarborControl.Abstractions.Boats.Commands
{
    public class StartDocking
    {
        public Guid BoatId { get; set; }
    }
}
