﻿using HarborControl.Abstractions.Boats.Entities;
using HarborControl.Abstractions.Enums;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HarborControl.Abstractions.Boats.Repositories
{
    public interface IBoatRepository
    {
        Task<Boat> GetBoat(Guid boatId);
        Task<IEnumerable<Boat>> GetBoats(DockStatus dockStatus);
        Task<bool> SaveBoat(Boat boat);
    }
}
