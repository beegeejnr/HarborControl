﻿using HarborControl.Abstractions.Boats.Commands;
using HarborControl.Abstractions.Boats.Entities;
using HarborControl.Abstractions.Enums;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HarborControl.Abstractions.Services
{
    public interface IHarborControlApplication
    {
        Task<Boat> GetBoat(Guid boatId);
        Task<IEnumerable<Boat>> GetBoats(DockStatus dockStatus);
        Task<bool> StartDockingBoat(Guid boatId);
        Task<bool> EndDockingBoat(Guid boatId);
        Task<Boat> EnqueueBoat(EnqueueBoat enqueueBoatCommand);
    }
}
