﻿using HarborControl.Abstractions;
using HarborControl.Abstractions.Boats.Commands;
using HarborControl.Abstractions.Boats.Entities;
using HarborControl.Abstractions.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace HarborControl.API.Controllers
{
    [Route("api/boats")]
    [ApiController]
    public class BoatsController : ControllerBase
    {
        private readonly IHarborControlApplication _application;
        private readonly ILogger<BoatsController> _logger;
        private readonly LoggingContext loggingContext;

        /// <summary>
        /// ComponentsController constructor
        /// </summary>
        /// <returns></returns>
        public BoatsController(IHarborControlApplication application,

        ILogger<BoatsController> logger)
        {
            _application = application;
            _logger = logger;
            loggingContext = new LoggingContext("localhost", "Harbor Control API (Command)", "BoatsController", "", 200);
        }


        /// <summary>
        /// Create component 
        /// </summary>
        /// <param name="component"></param>
        /// <returns></returns>

        [HttpPost]
        [Route("enqueue")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Boat), StatusCodes.Status400BadRequest)]
        [ProducesDefaultResponseType]
        public async Task<IActionResult> EnqueBoat([FromBody] Boat boat)
        {
            loggingContext.ActionName = MethodBase.GetCurrentMethod().Name;
            var data = JsonConvert.SerializeObject(boat);
            _logger.LogInformation("Server Name: {0} Api Name : {1} Contoller Name : {2}, Action Name :{3} Status Code :{4} \n Data :{5}", loggingContext.ServerName, loggingContext.APIName, loggingContext.ControllerName, loggingContext.ActionName, loggingContext.StatusCode, data);

            var command = new EnqueueBoat
            {
                Boat = boat
            };
            var commandResult = await _application.EnqueueBoat(command);
            return Ok(boat);
        }

        [HttpPut]
        [Route("start-docking/{boatId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Boat), StatusCodes.Status400BadRequest)]
        [ProducesDefaultResponseType]
        public async Task<IActionResult> StartDocking( Guid boatId)
        {
            loggingContext.ActionName = MethodBase.GetCurrentMethod().Name;
            var data = JsonConvert.SerializeObject(boatId);
            _logger.LogInformation("Server Name: {0} Api Name : {1} Contoller Name : {2}, Action Name :{3} Status Code :{4} \n Data :{5}", loggingContext.ServerName, loggingContext.APIName, loggingContext.ControllerName, loggingContext.ActionName, loggingContext.StatusCode, data);


            var commandResult = await _application.StartDockingBoat(boatId);
            return Ok();
        }

        [HttpPut]
        [Route("end-docking/{boatId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Boat), StatusCodes.Status400BadRequest)]
        [ProducesDefaultResponseType]
        public async Task<IActionResult> EndDocking( Guid boatId)
        {
            loggingContext.ActionName = MethodBase.GetCurrentMethod().Name;
            var data = JsonConvert.SerializeObject(boatId);
            _logger.LogInformation("Server Name: {0} Api Name : {1} Contoller Name : {2}, Action Name :{3} Status Code :{4} \n Data :{5}", loggingContext.ServerName, loggingContext.APIName, loggingContext.ControllerName, loggingContext.ActionName, loggingContext.StatusCode, data);

           
            var commandResult = await _application.EndDockingBoat(boatId);
            return Ok();
        }

        [HttpGet]
        [Route("docking")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Boat), StatusCodes.Status400BadRequest)]
        [ProducesDefaultResponseType]
        public async Task<IActionResult> Docking()
        {
            var boats = await _application.GetBoats(Abstractions.Enums.DockStatus.Docking);

            if (boats.Any())
            {
                return Ok(boats.First());
            }
            else { return NotFound(); }
        }

        [HttpGet]
        [Route("next")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Boat), StatusCodes.Status400BadRequest)]
        [ProducesDefaultResponseType]
        public async Task<IActionResult> DockingNext()
        {

            var boats = await _application.GetBoats(Abstractions.Enums.DockStatus.Waiting);

            if (boats.Any()) {
               return Ok( boats.OrderBy(b => b.ArrivalTime).First());
            }
            else { return NotFound(); }
           
           
        }

        [HttpGet]
        [Route("queue")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Boat), StatusCodes.Status400BadRequest)]
        [ProducesDefaultResponseType]
        public async Task<IActionResult> DockingQueue()
        {
            var boats = await _application.GetBoats(Abstractions.Enums.DockStatus.Waiting);

            return Ok(boats);
        }

        [HttpGet]
        [Route("docked")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Boat), StatusCodes.Status400BadRequest)]
        [ProducesDefaultResponseType]
        public async Task<IActionResult> Docked()
        {
            var boats = await _application.GetBoats(Abstractions.Enums.DockStatus.Docked);

            return Ok(boats);
        }
    }
}
