﻿using HarborControl.Abstractions.Boats.Commands;
using HarborControl.Abstractions.Boats.Entities;
using HarborControl.Abstractions.Boats.Repositories;
using HarborControl.Abstractions.Enums;
using HarborControl.Abstractions.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HarborControl.Core
{
    public class HarborControlApplication : IHarborControlApplication
    {
        private IBoatRepository _boatRepository;
        public HarborControlApplication(IBoatRepository boatRepository)
        {
            _boatRepository = boatRepository;
        }
        public async Task<bool> EndDockingBoat(Guid boatId)
        {
            var boat = await _boatRepository.GetBoat(boatId);
            boat.DockedTime = DateTime.Now;
            boat.Status = DockStatus.Docked;
            await _boatRepository.SaveBoat(boat);
            return true;
        }

        public Task<Boat> EnqueueBoat(EnqueueBoat enqueueBoatCommand)
        {
            return Task.Run(() => { _boatRepository.SaveBoat(enqueueBoatCommand.Boat); return enqueueBoatCommand.Boat; });
        }

        public Task<Boat> GetBoat(Guid boatId)
        {
            return   _boatRepository.GetBoat(boatId); 
        }

        public Task<IEnumerable<Boat>> GetBoats(DockStatus dockStatus)
        {
            return _boatRepository.GetBoats(dockStatus);
        }

        public async Task<bool> StartDockingBoat(Guid boatId)
        {
            var boat= await _boatRepository.GetBoat(boatId);
            boat.DockingTime= DateTime.Now;
            boat.Status = DockStatus.Docking;
            await _boatRepository.SaveBoat(boat);
            return true;
        }
    }
}
