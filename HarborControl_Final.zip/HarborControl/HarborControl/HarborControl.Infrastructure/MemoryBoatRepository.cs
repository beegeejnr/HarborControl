﻿using HarborControl.Abstractions.Boats.Entities;
using HarborControl.Abstractions.Boats.Repositories;
using HarborControl.Abstractions.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HarborControl.Infrastructure
{
    public class MemoryBoatRepository : IBoatRepository
    {
        private static List<Boat> _boats=  new List<Boat>();

        
        public async Task<Boat> GetBoat(Guid boatId)
        {
            return  await Task.FromResult(_boats.FirstOrDefault(b => b.Id.Equals(boatId)));
            
        }

        public async Task<IEnumerable<Boat>> GetBoats(DockStatus dockStatus)
        {
           return await Task.FromResult(_boats.Where(b=>b.Status== dockStatus));
        }

        public async Task<bool> SaveBoat(Boat boat)
        {
            _boats.Add(boat);
            return  await Task.FromResult(true);
        }
    }
}
