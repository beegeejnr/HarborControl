using HarborControl.Abstractions.Boats.Entities;
using HarborControl.Abstractions.Enums;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace HarborControl.WorkerService
{
    public class BoatGeneratorWorker : BackgroundService
    {
        private readonly ILogger<BoatGeneratorWorker> _logger;

        private readonly IHttpClientFactory _clientFactory;
        public BoatGeneratorWorker(IHttpClientFactory clientFactory, ILogger<BoatGeneratorWorker> logger)
        {
            _logger = logger;
            _clientFactory = clientFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            // random interval variable

            int interval = 0;
            int boatType = 1;
            Random randomizer = new Random();

            while (!stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation("Generating a boat: {time}", DateTimeOffset.Now);
                boatType = randomizer.Next(1, 3);
                var boat = new Boat()
                {
                    ArrivalTime = DateTime.Now,
                    Id = Guid.NewGuid(),
                    Status = DockStatus.Waiting,
                  
                    Type = (BoatType)boatType
                };
                boat.Name = $"{ Enum.GetName<BoatType>(boat.Type)}_{boat.Id.ToString().Substring(0,7)}";

                switch (boat.Type)
                {
                    case BoatType.Cargo:
                        boat.Speed = 5;
                        break;
                    case BoatType.Speed:
                        boat.Speed = 30;
                        break;
                    case BoatType.Sail:
                        boat.Speed = 10;
                        break;
                    default: throw new ArgumentException();
                }


                //check boat type, if boat type is sail, check wind speed, if wind speed is less than 5 skip the enqueing

                string jsonString = JsonSerializer.Serialize(boat);

                var payload = new StringContent(jsonString, Encoding.UTF8, "application/json");

                var client = _clientFactory.CreateClient();
                client.DefaultRequestHeaders.Add("Authorization", "YOUR_ASSEMBLY_AI_TOKEN");

                HttpResponseMessage response = await client.PostAsync("https://localhost:44395/api/boats/enqueue", payload);

                string responseJson = await response.Content.ReadAsStringAsync();

                //generate a waiting period for next arrival between 100 ms and 3000 ms
                interval = randomizer.Next(100, 3000);
                await Task.Delay(interval, stoppingToken);
            }
        }
    }
}
