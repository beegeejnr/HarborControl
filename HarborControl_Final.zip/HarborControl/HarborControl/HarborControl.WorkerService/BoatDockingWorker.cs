using HarborControl.Abstractions.Boats.Entities;
using HarborControl.Abstractions.Enums;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace HarborControl.WorkerService
{
    public class BoatDockingWorker : BackgroundService
    {
        private readonly ILogger<BoatDockingWorker> _logger;

        private readonly IHttpClientFactory _clientFactory;
        public BoatDockingWorker(IHttpClientFactory clientFactory, ILogger<BoatDockingWorker> logger)
        {
            _logger = logger;
            _clientFactory = clientFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            // random interval variable
            _logger.LogInformation("Docking a boat: {time}", DateTimeOffset.Now);
            int interval = 0;
         
            Random randomizer = new Random();
            var client = _clientFactory.CreateClient();
            while (!stoppingToken.IsCancellationRequested)
            {
                HttpResponseMessage docking = await client.GetAsync("https://localhost:44395/api/boats/docking");
                if (!docking.IsSuccessStatusCode)
                {
                    HttpResponseMessage nextDocking = await client.GetAsync("https://localhost:44395/api/boats/next");

                    if (nextDocking.IsSuccessStatusCode)
                    {
                       
                        try
                        {
                            var boat=  await nextDocking.Content.ReadAsAsync<Boat>();
                            HttpResponseMessage response = await client.PutAsync($"https://localhost:44395/api/boats/start-docking/{boat.Id}", null);
                            interval = 10 / boat.Speed;
                            await Task.Delay(interval, stoppingToken);
                        }
                        catch // Could be ArgumentNullException or UnsupportedMediaTypeException
                        {
                            Console.WriteLine("HTTP Response was invalid or could not be deserialised.");
                        }


                        
                    }
                    else
                    {
                        await Task.Delay(2000, stoppingToken);
                    }
                }
                else
                {

                    try
                    {
                        var boat = await docking.Content.ReadAsAsync<Boat>();
                        // todo: check if boat if done docking
                        //assume 2 sec to dock for all at this point
                        await Task.Delay(2000, stoppingToken);

                        HttpResponseMessage response = await client.PutAsync($"https://localhost:44395/api/boats/end-docking/{boat.Id}", null);
                       
                    }
                    catch // Could be ArgumentNullException or UnsupportedMediaTypeException
                    {
                        Console.WriteLine("HTTP Response was invalid or could not be deserialised.");
                    }
                }
            }


        }
    }
}
